#ifndef __App_Comm_Rx_Data_H
#define __App_Comm_Rx_Data_H

#include "Com_types.h"
#include "Int_SI24R1.h"
#include "FreeRTOS.h"
#include "task.h"
#include "Com_IMU.h"

#define FRAME0 'Y'
#define FRAME1 'Y'
#define FRAME2 'K'

// ����ң������
Com_Status App_Comm_Rx_Data(Remote_Struct *remote_data);

// ��������״̬
void App_Comm_Rx_Handle_Connect(Com_Status isReceived, Remote_Status *remote_status);

// ��������״̬
void App_Comm_Rx_Handle_Flight(Remote_Status remote_status, Remote_Struct *remote_data, Flight_Status *flight_status, Thr_Status *thr_status);


#endif



