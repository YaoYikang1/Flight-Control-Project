#include "Int_MPU6050.h"

Gyro_Acc_Struct gyro_acc_bias;

void Int_MPU6050_WriteByte(uint8_t reg, uint8_t data)
{ 
    HAL_I2C_Mem_Write(&hi2c1, MPU_IIC_ADDR_W, reg, I2C_MEMADD_SIZE_8BIT, &data, 1, 1000);
}

void Int_MPU6050_WriteBytes(uint8_t reg, uint8_t *data, uint8_t len)
{ 
    HAL_I2C_Mem_Write(&hi2c1, MPU_IIC_ADDR_W, reg, I2C_MEMADD_SIZE_8BIT, data, len, 1000);
}

void Int_MPU6050_ReadByte(uint8_t reg, uint8_t *data)
{ 
    HAL_I2C_Mem_Read(&hi2c1, MPU_IIC_ADDR_R, reg, I2C_MEMADD_SIZE_8BIT, data, 1, 1000);
}

void Int_MPU6050_ReadBytes(uint8_t reg, uint8_t *data, uint8_t len)
{ 
    HAL_I2C_Mem_Read(&hi2c1, MPU_IIC_ADDR_R, reg, I2C_MEMADD_SIZE_8BIT, data, len, 1000);
}

void Int_MPU6050_Calibration(void);


void Int_MPU6050_Init(void)
{
    // 1.��λ����ʱ������
    Int_MPU6050_WriteByte(MPU_PWR_MGMT1_REG, 0x80);
    HAL_Delay(200);
    Int_MPU6050_WriteByte(MPU_PWR_MGMT1_REG, 0x00);

    // 2. ����������
    // 2.1 ��������������
    Int_MPU6050_WriteByte(MPU_GYRO_CFG_REG, 0x18);
    // 2.2 ���ü��ٶȼ�����
    Int_MPU6050_WriteByte(MPU_ACCEL_CFG_REG, 0x18);

    // 2.3 ���ò�����
    Int_MPU6050_WriteByte(MPU_SAMPLE_RATE_REG, 0x01);
    // 2.4 �����˲�
    Int_MPU6050_WriteByte(MPU_CFG_REG, 0x02);

    // 2.5 �ر��жϣ��ر�I2C��չ���ر�FIFO
    Int_MPU6050_WriteByte(MPU_INT_EN_REG, 0x00);
    Int_MPU6050_WriteByte(MPU_USER_CTRL_REG, 0x00);
    Int_MPU6050_WriteByte(MPU_FIFO_EN_REG, 0x00);

    // // 2.6 ���Զ�ȡ��ַ�Ĵ���
    // uint8_t test_addr;
    // Int_MPU6050_ReadByte(MPU_DEVICE_ID_REG, &test_addr);

    // 2.7 ����ʱ��
    Int_MPU6050_WriteByte(MPU_PWR_MGMT1_REG, 0x01);
    // 2.8 ����������
    Int_MPU6050_WriteByte(MPU_PWR_MGMT2_REG, 0x00);

    Int_MPU6050_Calibration();
}

void Int_MPU6050_Read_Gyro(Gyro_Struct *gyro)
{
    uint8_t data[6] = {0};
    Int_MPU6050_ReadBytes(MPU_GYRO_XOUTH_REG, data, 6);

    gyro->x = (int16_t)(data[0] << 8 | data[1]);
    gyro->y = (int16_t)(data[2] << 8 | data[3]);
    gyro->z = (int16_t)(data[4] << 8 | data[5]);
}

void Int_MPU6050_Read_Acc(Acc_Struct *acc)
{
    uint8_t data[6] = {0};
    Int_MPU6050_ReadBytes(MPU_ACCEL_XOUTH_REG, data, 6);

    acc->x = (int16_t)(data[0] << 8 | data[1]);
    acc->y = (int16_t)(data[2] << 8 | data[3]);
    acc->z = (int16_t)(data[4] << 8 | data[5]);
}

void Int_MPU6050_Read(Gyro_Acc_Struct *gyro_acc)
{
    Int_MPU6050_Read_Gyro(&gyro_acc->gyro);
    Int_MPU6050_Read_Acc(&gyro_acc->acc);

    // ʹ��У׼ֵ
    gyro_acc->gyro.x -= gyro_acc_bias.gyro.x;
    gyro_acc->gyro.y -= gyro_acc_bias.gyro.y;
    gyro_acc->gyro.z -= gyro_acc_bias.gyro.z;
    gyro_acc->acc.x -= gyro_acc_bias.acc.x;
    gyro_acc->acc.y -= gyro_acc_bias.acc.y;
    gyro_acc->acc.z -= gyro_acc_bias.acc.z - 16384;

}


void Int_MPU6050_Calibration(void)
{
    // �жϵ�ǰ�ɻ��Ƿ�ͣ��
    // ����100�ν��ٶȵ�ֵ����һ�εĲ���û��С�ĸ���
    uint8_t count = 100;
    Gyro_Struct last_gyro;
    Gyro_Struct cur_gyro;
    Int_MPU6050_Read_Gyro(&last_gyro);
    HAL_Delay(2);
    while (count < 100)
    {
        Int_MPU6050_Read_Gyro(&cur_gyro);
        if (ABS(cur_gyro.x - last_gyro.x) < 100 && ABS(cur_gyro.y - last_gyro.y) < 100 && ABS(cur_gyro.z - last_gyro.z) < 100)
        {
            count++;
        }
        else
        {
            count = 0;
        }
    }
    // �ṹ��=�ṹ�壬Ч���Ǻ���Ľṹ�����԰�����ֵ��ǰ��Ľṹ��
    last_gyro = cur_gyro;
    HAL_Delay(2);

    // ��ȡ��ǰֵ��Ϊƫ�����������ٴ�ȡƽ��ֵ
    Gyro_Acc_Struct gyro_acc_temp;
    int32_t gyro_acc_sum[6] = {0};
    for (uint8_t i = 0; i < 200; i++)
    {
        Int_MPU6050_Read(&gyro_acc_temp);

        gyro_acc_sum[0] += gyro_acc_temp.gyro.x;
        gyro_acc_sum[1] += gyro_acc_temp.gyro.y;
        gyro_acc_sum[2] += gyro_acc_temp.gyro.z;
        gyro_acc_sum[3] += gyro_acc_temp.acc.x;
        gyro_acc_sum[4] += gyro_acc_temp.acc.y;
        gyro_acc_sum[5] += gyro_acc_temp.acc.z;
        HAL_Delay(2);
    }

    gyro_acc_bias.gyro.x = gyro_acc_sum[0] / 200;
    gyro_acc_bias.gyro.y = gyro_acc_sum[1] / 200;
    gyro_acc_bias.gyro.z = gyro_acc_sum[2] / 200;
    gyro_acc_bias.acc.x = gyro_acc_sum[3] / 200;
    gyro_acc_bias.acc.y = gyro_acc_sum[4] / 200;
    gyro_acc_bias.acc.z = gyro_acc_sum[5] / 200;    
}

