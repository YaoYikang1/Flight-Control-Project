#include "Int_IP5305T.h"


static void Int_IP5305T_Presed(void)
{
    // POWER_KEY����Ϊ0������30msС��2s
    HAL_GPIO_WritePin(POWER_KEY_GPIO_Port, POWER_KEY_Pin, GPIO_PIN_RESET);
    vTaskDelay(80);
    //�ͷ�����
    HAL_GPIO_WritePin(POWER_KEY_GPIO_Port, POWER_KEY_Pin, GPIO_PIN_SET);
}


void Int_IP5305T_Start(void)
{
    Int_IP5305T_Presed();
}


void Int_IP5305T_Stop(void)
{
    Int_IP5305T_Presed();
    vTaskDelay(200);
    Int_IP5305T_Presed();  
}


