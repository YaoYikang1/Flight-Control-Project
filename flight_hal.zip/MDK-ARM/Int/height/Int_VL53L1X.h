#ifndef __INT_VL53L1X_H__
#define __INT_VL53L1X_H__

#include "vl53l1_platform.h"
#include "vl53l1_types.h"
#include "VL53L1X_api.h"
#include "VL53L1X_calibration.h"
#include "Com_debug.h"


void Int_VL53L1X_Init(void);

void Int_VL53L1X_GetDistance(uint16_t *distance);


#endif

