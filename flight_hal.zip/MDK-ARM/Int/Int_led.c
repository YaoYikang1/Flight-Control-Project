#include "Int_led.h"


void Int_LED_TurnOn(LED_Struct *led)
{
    HAL_GPIO_WritePin(led->port, led->pin, GPIO_PIN_RESET);
}


void Int_LED_TurnOff(LED_Struct *led)
{
    HAL_GPIO_WritePin(led->port, led->pin, GPIO_PIN_SET);
}


void Int_LED_Blink(LED_Struct *led, uint16_t period)
{
    // �鿴��ǰʱ��
    TickType_t current_tick = xTaskGetTickCount();
    if (current_tick - led->last_tick >= period)
    {
        // ��תһ������
        HAL_GPIO_TogglePin(led->port, led->pin);
        led->last_tick = current_tick;
    }    
}


