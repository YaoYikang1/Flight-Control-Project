#ifndef __INT_MOTOR_H
#define __INT_MOTOR_H

#include "tim.h"
#include "Com_types.h"


void Int_Motor_Init(void);

void Int_Motor_Start(void);

void Int_Motor_Set_Speed(Motor_Struct *motor);

#endif /* __INT_MOTOR_H */

