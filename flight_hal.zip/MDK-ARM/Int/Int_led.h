#ifndef __INT_LED_H
#define __INT_LED_H

#include "gpio.h"
#include "Com_types.h"
#include "FreeRTOS.h"
#include "task.h"

void Int_LED_TurnOn(LED_Struct *led);

void Int_LED_TurnOff(LED_Struct *led);

void Int_LED_Blink(LED_Struct *led, uint16_t period);


#endif /* __INT_LED_H */


