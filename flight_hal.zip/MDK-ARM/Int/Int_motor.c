#include "Int_motor.h"


void Int_Motor_Init(void)
{
    // ������ʱ��
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);
    HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_4);
}


/**
 * @brief �����ڲ���������
 */
void Int_Motor_Start(void)
{
    __HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1, 100);
    __HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_2, 100);
    __HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_3, 100);
    __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_4, 100);
}


/**
 * @brief ʹ�ýṹ�����õ��ת��
 */
void Int_Motor_Set_Speed(Motor_Struct *motor)
{
    __HAL_TIM_SetCompare(motor->htim, motor->channel, motor->speed);
}

