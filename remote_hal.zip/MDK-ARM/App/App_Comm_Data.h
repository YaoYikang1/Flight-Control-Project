#ifndef __App_Comm_Data_H
#define __App_Comm_Data_H

#include "Int_SI24R1.h"
#include "Com_types.h"
#include "FreeRTOS.h"
#include "task.h"


#define FRAME0 'Y'
#define FRAME1 'Y'
#define FRAME2 'K'


void App_Comm_Send_Data(Remote_Struct *remote_data);



#endif


