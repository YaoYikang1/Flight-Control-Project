#ifndef __APP_PROCESS_DATA_H__
#define __APP_PROCESS_DATA_H


#include "Int_key.h"
#include "Com_debug.h"
#include "Com_types.h"
#include "Int_joystick.h"

#define LIMIT(x, min, max) (x < min ? min : (x > max ? max : x))


void App_Process_Key_Data(Remote_Struct *remote_data);

void App_Process_Joystick_Data(Remote_Struct *remote_data);

#endif

