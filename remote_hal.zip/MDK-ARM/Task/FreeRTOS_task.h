#ifndef __FREERTOS_TASK_H__
#define __FREERTOS_TASK_H__

#include "FreeRTOS.h"
#include "task.h"
#include "Com_debug.h"
#include "main.h"
#include "Int_IP5305T.h"
#include "Com_types.h"
#include "Int_SI24R1.h"
#include "App_Process_Data.h"
#include "App_Comm_Data.h"
#include "App_Display.h"

void FreeRTOS_Start(void);


#endif

