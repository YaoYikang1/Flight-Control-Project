#ifndef __INT_IP5305T_H
#define __INT_IP5305T_H

#include "gpio.h"
#include "FreeRTOS.h"
#include "task.h"


void Int_IP5305T_Start(void);



#endif /* __INT_IP5305T_H */

