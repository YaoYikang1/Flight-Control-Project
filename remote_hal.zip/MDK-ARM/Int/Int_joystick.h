#ifndef __INT_JOYSTICK_H
#define __INT_JOYSTICK_H

#include "adc.h"
#include "Com_types.h"


void Int_Joystick_Init(void);

void Int_Joystick_Scan(Remote_Struct *remote_data);


#endif

