#ifndef __INT_KEY_H
#define __INT_KEY_H 


#include "gpio.h"
#include "com_types.h"
#include "FreeRTOS.h"
#include "task.h"


Key_Type Int_Key_Scan(void);




#endif


