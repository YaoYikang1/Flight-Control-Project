#include "Int_key.h"


#define READ_KEY_UP() (HAL_GPIO_ReadPin(KEY_UP_GPIO_Port, KEY_UP_Pin))
#define READ_KEY_DOWN() (HAL_GPIO_ReadPin(KEY_DOWN_GPIO_Port, KEY_DOWN_Pin))
#define READ_KEY_LEFT() (HAL_GPIO_ReadPin(KEY_LEFT_GPIO_Port, KEY_LEFT_Pin))
#define READ_KEY_RIGHT() (HAL_GPIO_ReadPin(KEY_RIGHT_GPIO_Port, KEY_RIGHT_Pin))
#define READ_KEY_LEFT_X() (HAL_GPIO_ReadPin(KEY_LEFT_X_GPIO_Port, KEY_LEFT_X_Pin))
#define READ_KEY_RIGHT_X() (HAL_GPIO_ReadPin(KEY_RIGHT_X_GPIO_Port, KEY_RIGHT_X_Pin))

Key_Type Int_Key_Scan(void)
{
    if (READ_KEY_UP() == GPIO_PIN_RESET)
    {
        // ����
        vTaskDelay(10);
        if (READ_KEY_UP() == GPIO_PIN_RESET)
        {
            // ȷ�ϰ��£��ȴ�����̧��
            while (READ_KEY_UP() == GPIO_PIN_RESET)
                ;
            return KEY_UP;
        }                
    }

    if (READ_KEY_DOWN() == GPIO_PIN_RESET)
    {
        // ����
        vTaskDelay(10);
        if (READ_KEY_DOWN() == GPIO_PIN_RESET)
        {
            // ȷ�ϰ��£��ȴ�����̧��
            while (READ_KEY_DOWN() == GPIO_PIN_RESET)
                ;
            return KEY_DOWN;
        }
    }

    if (READ_KEY_LEFT() == GPIO_PIN_RESET)
    {
        // ����
        vTaskDelay(10);
        if (READ_KEY_LEFT() == GPIO_PIN_RESET)
        {
            // ȷ�ϰ��£��ȴ�����̧��
            while (READ_KEY_LEFT() == GPIO_PIN_RESET)
                ;
            return KEY_LEFT;
        }
    }

    if (READ_KEY_RIGHT() == GPIO_PIN_RESET)
    {
        // ����
        vTaskDelay(10);
        if (READ_KEY_RIGHT() == GPIO_PIN_RESET)
        {
            // ȷ�ϰ��£��ȴ�����̧��
            while (READ_KEY_RIGHT() == GPIO_PIN_RESET)
                ;
            return KEY_RIGHT;
        }
    }

    // ������̧���ʱ���ȥ���µ�ʱ�� > 500ms
    // �̰���̧���ʱ���ȥ���µ�ʱ�� < 500ms
    if (READ_KEY_LEFT_X() == GPIO_PIN_RESET)
    {
        // ��ȡ���µ�ʱ��
        uint32_t start = xTaskGetTickCount();
        vTaskDelay(10);
        if (READ_KEY_LEFT_X() == GPIO_PIN_RESET)
        {
            // ȷ�ϰ��£��ȴ�����̧��
            while (READ_KEY_LEFT_X() == GPIO_PIN_RESET)
                ;
            uint32_t stop = xTaskGetTickCount();
            if (stop - start > 500)
                return KEY_LEFT_X_LONG;
            else
                return KEY_LEFT_X;
        }
    }

    if (READ_KEY_RIGHT_X() == GPIO_PIN_RESET)
    {
        // ��ȡ���µ�ʱ��
        uint32_t start = xTaskGetTickCount();
        vTaskDelay(10);
        if (READ_KEY_RIGHT_X() == GPIO_PIN_RESET)
        {
            // ȷ�ϰ��£��ȴ�����̧��
            while (READ_KEY_RIGHT_X() == GPIO_PIN_RESET)
                ;
            uint32_t stop = xTaskGetTickCount();
            if (stop - start > 500)
                return KEY_RIGHT_X_LONG;
            else
                return KEY_RIGHT_X;
        }
    }
    return KEY_NONE;    
}


